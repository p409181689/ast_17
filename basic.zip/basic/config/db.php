<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=mysql.scm.tees.ac.uk;dbname=p4091816',
    'username' => 'p4091816',
    'password' => 'OTzi3+5^7GV:',
    'charset' => 'utf8',
];
