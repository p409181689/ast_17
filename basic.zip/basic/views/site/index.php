<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';

if (Yii::$app-> user->isGuest){
  $dashboard = <<<DASH
  <div class="site-index">

      <div class="jumbotron">


          <img src="https://p4091816.scm.tees.ac.uk/basic/web/assets/718866fb/img/logo.png" alt="Alex Essay Writing Tool" width="450" height="200">


      </div>

      <div class="body-content">

<h2>Please Login</h2>


    </div>



                  </div>
    </div>

      </div>
  </div>


DASH;

}else{
  $dashboard = <<<DASH2
  <h1> Logged in <h1>
  <div class="site-index">

      <div class="jumbotron">


          <img src="https://p4091816.scm.tees.ac.uk/basic/web/assets/718866fb/img/logo.png" alt="Alex Essay Writing Tool" width="450" height="200">

  <p><a class="btn btn-lg btn-success" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/backend-user/create">Create a user</a></p>
      </div>

      <div class="body-content">


          <div class="row">
              <div class="col-lg-4">
                  <h2>Screens</h2>
  	<p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/screens/">Screens</a></p>
              </div>
              <div class="col-lg-4">
                  <h2>Steps</h2>



                  <p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/steps/">Steps</a></p>
              </div>
              <div class="col-lg-4">
                  <h2>Text Box</h2>


                  <p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/box/">Text Box</a></p>
              </div>
          </div>

              </div>
              <div class="col-lg-4">
                  <h2>Text</h2>



                  <p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/text/">Text</a></p>
              </div>
              <div class="col-lg-4">
                  <h2>Images</h2>


                  <p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/images/">Images</a></p>
              </div>
          </div>
   <div class="col-lg-4">
                  <h2>Video</h2>
  		<p><a class="btn btn-default" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/video/">Video</a></p>
              </div>

  	</div>



                  </div>
  	</div>

      </div>
  </div>
DASH2;
}
print $dashboard;
  ?>
