<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

$this->title = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

        <div class="body-content">



        <div class="row">
            <div class="col-lg-4">
                <h2>This is a Content Management System for the use of the Alex Essay Learning Tool at https://www.alexessaytool.com. It enables you to upload text, images & video according to the front ends layout.</h2>



                
            

<p><a class="btn btn-lg btn-success" href="https://p4091816.scm.tees.ac.uk/basic/web/index.php/site/index">Return</a></p>
               
            </div>
        </div>

    </div>
</div>